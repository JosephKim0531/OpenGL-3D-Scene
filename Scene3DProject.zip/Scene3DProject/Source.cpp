#include <glad/glad.h>
#include <GLFW/glfw3.h>     // GLFW library
#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
//#include <GL/glew.h>        // GLEW library
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"      //library to load multiple types of image files

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "camera.h" //camera header file that was slightly modified from LearnOpenGL
#include "shader.h"
#include "cylinder.h"
#include "sphere.h"
using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "3D Scene Project"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vaos[2];         // Handle for the vertex array object
        GLuint vbos[2];     // Handles for the vertex buffer objects/element buffer objects
        GLuint nIndices;    // Number of indices of the mesh
    };

    //Declare main GLFW window and set to null
    GLFWwindow* gWindow = nullptr;
    // mesh data variables for objects in scene
    GLMesh strap1Mesh;
    GLMesh strap2Mesh;
    GLMesh watchFaceMesh;
    GLMesh deskMesh;
    GLMesh airpodMesh;
    GLMesh lightCubeMesh;
    GLMesh pencilTipMesh;
    GLMesh glassFramesMesh;
    GLMesh golfFaceMesh;
    GLMesh stickyNoteMesh;

    // declare variable for Shader programs
    GLuint strapProgramId;
    GLuint watchFaceProgramId;
    GLuint deskProgramId;
    GLuint airpodProgramId;
    GLuint pencilProgramId;
    GLuint pencilTipProgramId;
    GLuint lightCubeProgramId;
    GLuint glassesProgramId;
    GLuint glassFramesProgramId;
    GLuint sphereProgramId;
    GLuint golfFaceProgramId;
    GLuint golfShaftProgramId;
    GLuint stickyNoteProgramId;

    //global variables for lighting data
    glm::vec3 pointLight1Color = glm::vec3(1.0f, 1.0f, 0.35f);
    glm::vec3 pointLight1Intensity = glm::vec3(1.0f);
    glm::vec3 pointLight2Color = glm::vec3(1.0f, 1.0f, 0.35f);
    glm::vec3 pointLight2Intensity = glm::vec3(1.0f);

    //camera variables and initialization
    Camera gCamera(glm::vec3(0.0f, 0.0f, 3.0f));
    //set the cursor starting point at the center of the screen width and height
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    //set timing between frame variables to 0.0
    //variables will be used to calculate the time between the current frame and last frame
    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    //variable for perspective to ortho projection
    bool isPerspective = true;
}


/* Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized, render graphics on the screen,
 * process user input, register mouse movements,
 * create all the object meshes, set the uniforms for lighting shader, load and process textures
 */

bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void setShaderUniforms(Shader shader, glm::vec3 lightPositions[], glm::mat4& projMat);
void setFaceShaderUniforms(Shader shader, glm::vec3 lightPositions[], glm::mat4& projMat);
void createStrapMesh(GLMesh& mesh);
void createFaceMesh(GLMesh& mesh);
void createDeskMesh(GLMesh& mesh);
void createAirpodMesh(GLMesh& mesh);
void createLightCubeMesh(GLMesh& mesh);
void createPencilTipMesh(GLMesh& mesh);
void createGlassFramesMesh(GLMesh& mesh);
void createPlaneMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTextureRepeat(const char* filename, GLuint& textureId);
bool UCreateTextureClamp(const char* filename, GLuint& textureId, float borderColor[]);
void UDestroyTexture(GLuint textureId);
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);

//the main function
int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    //build and compile the shader programs
    Shader strapProgramId("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
    Shader watchFaceProgramId("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
    Shader deskProgramId("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
    Shader airpodProgramId("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
    Shader pencilProgramId("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
    Shader pencilTipProgramId("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
    Shader glassesProgramId("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
    Shader glassFramesProgramId("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
    Shader stickyNoteProgramId("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
    Shader sphereProgramId("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
    Shader golfFaceProgramId("shaderfiles/6.multiple_lights.vs","shaderfiles/6.multiple_lights.fs");
    Shader golfShaftProgramId("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
    Shader lightCubeProgramId( "shaderfiles/6.light_cube.vs", "shaderfiles/6.light_cube.fs");


    // Create the meshes for all the objects in the scene
    // Calls the appropriate create mesh function to create VAOs with vertex attributes 
    createStrapMesh(strap1Mesh);
    //createStrapMesh(strap2Mesh);
    createFaceMesh(watchFaceMesh);
    createDeskMesh(deskMesh);
    createAirpodMesh(airpodMesh);
    createLightCubeMesh(lightCubeMesh);
    createPencilTipMesh(pencilTipMesh);
    createGlassFramesMesh(glassFramesMesh);
    createFaceMesh(golfFaceMesh);
    createPlaneMesh(stickyNoteMesh);

    //positions for the point lights
    //added additional lights to properly view the scene
    glm::vec3 pointLightPositions[] = {
        glm::vec3(-4.0f, 3.0f, -6.0f),
        glm::vec3(6.0f, 3.0f, -6.0f),
        glm::vec3(-4.0f, 3.0f, 4.0f),
        glm::vec3(6.0f, 3.0f, 4.0f),
    };

    //load textures for texels and for diffuse and specular lighting
    unsigned int strapDiffuseMap, strapSpecularMap, watchDiffuseMap, watchSpecularMap, deskDiffuseMap, deskSpecularMap, 
        airpodDiffuseMap, airpodSpecularMap, pencilDiffuseMap, pencilSpecularMap, pencilTipDiffuseMap, pencilTipSpecularMap,
        glassesDiffuseMap, glassesSpecularMap, glassFramesDiffuseMap, glassFramesSpecularMap, 
        golfFaceDiffuseMap, golfFaceSpecularMap, blackDiffuseMap, graySpecularMap, 
        silverDiffuseMap, silverSpecularMap, yellowDiffuseMap, yellowSpecularMap;
    //call the appropriate texture functions for each image
    //texture 0 & 1
    const char* texFilename = "images/strap_texture.jpg";
    if (!UCreateTextureRepeat(texFilename, strapDiffuseMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    texFilename = "images/strap_texture_specular.jpg";
    if (!UCreateTextureRepeat(texFilename, strapSpecularMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    //texture 2 & 3
    float faceClampColor[] = { 0.0f, 0.0f, 0.0f, 1.0f }; //black border color for clamp texture wrap
    texFilename = "images/watch_face.jpg";
    if (!UCreateTextureClamp(texFilename, watchDiffuseMap, faceClampColor)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    texFilename = "images/watch_face_specular.jpg";
    if (!UCreateTextureClamp(texFilename, watchSpecularMap, faceClampColor)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    //texture 4 & 5
    texFilename = "images/desk_texture_metallic.jpg";
    if (!UCreateTextureRepeat(texFilename, deskDiffuseMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    texFilename = "images/desk_texture_metallic_specular.jpg";
    if (!UCreateTextureRepeat(texFilename, deskSpecularMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    //texture 6 & 7 
    float airpodClampColor[] = { 1.0f, 1.0f, 1.0f, 1.0f }; //white border color
    texFilename = "images/airpod.jpg";
    if (!UCreateTextureClamp(texFilename, airpodDiffuseMap, airpodClampColor)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    texFilename = "images/airpod_specular.jpg";
    if (!UCreateTextureClamp(texFilename, airpodSpecularMap, airpodClampColor)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    //texture 8 & 9
    texFilename = "images/pencil.jpg";;
    if (!UCreateTextureRepeat(texFilename, pencilDiffuseMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    texFilename = "images/pencil_specular.jpg";
    if (!UCreateTextureRepeat(texFilename, pencilSpecularMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    //texture 10 & 11
    //Use texture for pencil tip and glass frames
    texFilename = "images/black_tip.jpg";
    if (!UCreateTextureRepeat(texFilename, pencilTipDiffuseMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    texFilename = "images/black_tip_specular.jpg";
    if (!UCreateTextureRepeat(texFilename, pencilTipSpecularMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    //texture 12 & 13
    texFilename = "images/glass.png";
    if (!UCreateTextureRepeat(texFilename, glassesDiffuseMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    texFilename = "images/glass_specular.png";
    if (!UCreateTextureRepeat(texFilename, glassesSpecularMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    //texture 14 & 15
    texFilename = "images/black.png";
    if (!UCreateTextureRepeat(texFilename, blackDiffuseMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    texFilename = "images/gray.png";
    if (!UCreateTextureRepeat(texFilename, graySpecularMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    //texture 16 & 17
    texFilename = "images/golf.jpg";
    if (!UCreateTextureRepeat(texFilename, golfFaceDiffuseMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    texFilename = "images/golf_specular.jpg";
    if (!UCreateTextureRepeat(texFilename, golfFaceSpecularMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    //texture 18 & 19
    texFilename = "images/silver.png";
    if (!UCreateTextureRepeat(texFilename, silverDiffuseMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    texFilename = "images/silver_specular.png";
    if (!UCreateTextureRepeat(texFilename, silverSpecularMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    //texture 20 & 21
    texFilename = "images/yellow.png";
    if (!UCreateTextureRepeat(texFilename, yellowDiffuseMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }
    texFilename = "images/yellow_specular.png";
    if (!UCreateTextureRepeat(texFilename, yellowSpecularMap)) {
        std::cout << "Failed to load texture " << texFilename << std::endl;
        return EXIT_FAILURE;
    }

    //configure the shaders for the each object textures
    //first declare the shader program to use. THen send the appropriate texture images to the uniforms of said shader program.
    //strap texture
    strapProgramId.use();
    strapProgramId.setInt("material.diffuse", 0);
    strapProgramId.setInt("material.specular", 1);
    //watch texture
    watchFaceProgramId.use();
    watchFaceProgramId.setInt("material.diffuse", 2);
    watchFaceProgramId.setInt("material.specular", 3);
    deskProgramId.use();
    //metallic desk texture
    deskProgramId.setInt("material.diffuse", 4);
    deskProgramId.setInt("material.specular", 5);
    airpodProgramId.use();
    //airpod texture
    airpodProgramId.setInt("material.diffuse", 6);
    airpodProgramId.setInt("material.specular", 7);
    pencilProgramId.use();
    //pencil base texture yellow grain
    pencilProgramId.setInt("material.diffuse", 8);
    pencilProgramId.setInt("material.specular", 9);
    pencilTipProgramId.use();
    //pencil tip texture, a graphite looking black
    pencilTipProgramId.setInt("material.diffuse", 10);
    pencilTipProgramId.setInt("material.specular", 11);
    glassesProgramId.use();
    //glasses texture, a reflective white
    glassesProgramId.setInt("material.diffuse", 12);
    glassesProgramId.setInt("material.specular", 13);
    glassFramesProgramId.use();
    //glasses frame texture, a black with lighted black and white image to create shininess
    glassFramesProgramId.setInt("material.diffuse", 14);
    glassFramesProgramId.setInt("material.specular", 15);
    //same texture as glasses frame but for the golf club base
    sphereProgramId.use();
    sphereProgramId.setInt("material.diffuse", 14);
    sphereProgramId.setInt("material.specular", 15);
    //golf face texture that has horizontal stripes
    golfFaceProgramId.use();
    golfFaceProgramId.setInt("material.diffuse", 16);
    golfFaceProgramId.setInt("material.specular", 17);
    //golf shaft insert texture, a silver
    golfShaftProgramId.use();
    golfShaftProgramId.setInt("material.diffuse", 18);
    golfShaftProgramId.setInt("material.specular", 19);
    //sticky note texture, yellow
    stickyNoteProgramId.use();
    stickyNoteProgramId.setInt("material.diffuse", 20);
    stickyNoteProgramId.setInt("material.specular", 21);
    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
// --------------------
        float currentFrame = glfwGetTime(); //create dynamic currentFrame float that registers time value
        gDeltaTime = currentFrame - gLastFrame; //calculate the deltaTime between last and current frame
        gLastFrame = currentFrame;              //store the time for the last frame

        // call UProcessInput for user input
        UProcessInput(gWindow);

        // render
        // ------
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f); //background color
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        //view/projection matrices for shaders 
        //need to define projection matrix here to deal with perspective versus ortho view
        glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);
        //need to define view matrix for light bulb positions and rendering
        glm::mat4 view = gCamera.GetViewMatrix();

        //logic to toggle between perspective and ortho projection with the p key
        if (isPerspective == true) {
            //set and pass the perpsective projection matrix to the shader program
            projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

        }
        else {
            //adjust the width and height of viewport
            GLfloat oWidth = (GLfloat)WINDOW_WIDTH * 0.01f; //10% of width
            GLfloat oHeight = (GLfloat)WINDOW_HEIGHT * 0.01f; //10% of height
            //set and pass the ortho projection matrix to the shader program
            projection = glm::ortho(-oWidth, oWidth, -oHeight, oHeight, 0.1f, 100.0f);
        }


        //=============================================================
        //logic for watch straps
        setShaderUniforms(strapProgramId, pointLightPositions, projection);
        
        //bind diffuse map
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, strapDiffuseMap);
        //bind specular map
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, strapSpecularMap);

        //select the strap vao to render 
        glBindVertexArray(strap1Mesh.vaos[0]);
        //model matrix for world transformation
        glm::mat4 model = glm::mat4(1.0f);
        glm::mat4 scale = glm::mat4(1.0f);
        glm::mat4 rotation = glm::mat4(1.0f);
        glm::mat4 trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(-1.85f, -0.15f, -1.8f));
        model = glm::rotate(model, glm::radians(-60.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::scale(model, glm::vec3(1.34f, 0.045f, 0.335f));

        strapProgramId.setMat4("model", model);

        //draw the strap
        glDrawArrays(GL_TRIANGLES, 0, strap1Mesh.nIndices);

        //select the next strap vao to render 
        //model matrix for world transformation
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(-1.05f, -0.15f, -0.4f));
        model = glm::rotate(model, glm::radians(-60.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::scale(model, glm::vec3(1.34f, 0.045f, 0.335f));

        strapProgramId.setMat4("model", model);
        //draw the strap
        glDrawArrays(GL_TRIANGLES, 0, strap1Mesh.nIndices);

        //=====================================================
        //Logic for watch face
        setShaderUniforms(watchFaceProgramId, pointLightPositions, projection);

        //bind diffuse map
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, watchDiffuseMap);
        //bind specular map
        glActiveTexture(GL_TEXTURE3);
        glBindTexture(GL_TEXTURE_2D, watchSpecularMap);

        //select the watch face vao to render 
        glBindVertexArray(watchFaceMesh.vaos[0]);
        //model matrix for world transformation
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(-1.5f, -0.15f, -1.0f));
        model = glm::rotate(model, glm::radians(-60.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::scale(model, glm::vec3(0.536f, 0.1005f, 0.536f));

        watchFaceProgramId.setMat4("model", model);
        //draw the watch face
        glDrawArrays(GL_TRIANGLES, 0, watchFaceMesh.nIndices);

        //=============================================================
        //Logic for the desk
        // set lighting Uniforms for desk 
        setShaderUniforms(deskProgramId, pointLightPositions, projection);

        //bind diffuse map
        glActiveTexture(GL_TEXTURE4);
        glBindTexture(GL_TEXTURE_2D, deskDiffuseMap);
        //bind specular map
        glActiveTexture(GL_TEXTURE5);
        glBindTexture(GL_TEXTURE_2D, deskSpecularMap);

        //select the desk vao to render 
        glBindVertexArray(deskMesh.vaos[0]);
        //model matrix for world transformation
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(1.0f, -0.6f, 1.0f));
        model = glm::scale(model, glm::vec3(10.0f, 0.8f, 8.0f));

        deskProgramId.setMat4("model", model);

        //draw the desk
        glDrawArrays(GL_TRIANGLES, 0, deskMesh.nIndices);
        //===========================================================================

        //Logic for Airpod 
        // set lighting Uniforms for airpod 
        setShaderUniforms(airpodProgramId, pointLightPositions, projection);
       
        //bind diffuse map
        glActiveTexture(GL_TEXTURE6);
        glBindTexture(GL_TEXTURE_2D, airpodDiffuseMap);
        //bind specular map
        glActiveTexture(GL_TEXTURE7);
        glBindTexture(GL_TEXTURE_2D, airpodSpecularMap);

        //select the airpod vao to render 
        glBindVertexArray(airpodMesh.vaos[0]);

        //model matrix for world transformation
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(0.3f, -0.05f, 0.1f));
        model = glm::rotate(model, glm::radians(20.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::scale(model, glm::vec3(0.6f, 0.25f, 0.7f));

        airpodProgramId.setMat4("model", model);

        
        //draw the airpod base
        glDrawArrays(GL_TRIANGLES, 0, airpodMesh.nIndices);
        /*
        //draw the airpod side 1
         //model matrix for world transformation
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(0.3f, -0.05f, 0.1f));
        //model = glm::rotate(model, glm::radians(20.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = glm::rotate(model, glm::radians(20.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::scale(model, glm::vec3(0.6f, 0.25f, 0.7f));

        airpodProgramId.setMat4("model", model);
        //cylinder (float radius, int numSlices, float height, bool withPositions, bool withTextureCoordinates, bool withNormals)
        static_meshes_3D::Cylinder airSide1(0.235, 50, 2.25, true, true, true);
        airSide1.renderHalf();
        */
        
        //====================================================
     
        // pencil base logic 
        // set lighting Uniforms for pencil base
        setShaderUniforms(pencilProgramId, pointLightPositions, projection);

        //bind diffuse map
        glActiveTexture(GL_TEXTURE8);
        glBindTexture(GL_TEXTURE_2D, pencilDiffuseMap);
        //bind specular map
        glActiveTexture(GL_TEXTURE9);
        glBindTexture(GL_TEXTURE_2D, pencilSpecularMap);

        //model matrix for world transformation
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(1.0f, -0.12f, -0.5f));
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::rotate(model, glm::radians(-35.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));

        pencilProgramId.setMat4("model", model);
        static_meshes_3D::Cylinder pencil(0.07, 50, 1.8, true, true, true);
        pencil.render();


       
        //=========================================================
        
        //Logic for pencil tip
        // set lighting Uniforms for pencil base
        setShaderUniforms(pencilTipProgramId, pointLightPositions, projection);
       
        //bind diffuse map
        glActiveTexture(GL_TEXTURE10);
        glBindTexture(GL_TEXTURE_2D, pencilTipDiffuseMap);
        //bind specular map
        glActiveTexture(GL_TEXTURE11);
        glBindTexture(GL_TEXTURE_2D, pencilTipSpecularMap);

        //select the pencil tip vao to render 
        glBindVertexArray(pencilTipMesh.vaos[0]);
        //model matrix for world transformation
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(0.635f, -0.12f, -1.4f));
        model = glm::rotate(model, glm::radians(-90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::rotate(model, glm::radians(35.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = glm::scale(model, glm::vec3(0.11f, 0.11f, 0.11f));

        pencilTipProgramId.setMat4("model", model);

        //draw the pencil tip
        glDrawArrays(GL_TRIANGLES, 0, pencilTipMesh.nIndices);
        
        //=================================================================
         // glasses logic 
        // set lighting Uniforms for glasses
        setShaderUniforms(glassesProgramId, pointLightPositions, projection);
        
        //bind diffuse map
        glActiveTexture(GL_TEXTURE12);
        glBindTexture(GL_TEXTURE_2D, glassesDiffuseMap);
        //bind specular map
        glActiveTexture(GL_TEXTURE13);
        glBindTexture(GL_TEXTURE_2D, glassesSpecularMap);

        //model matrix for world transformation of first glass
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(1.0f, 0.22f, -1.7f));
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::rotate(model, glm::radians(35.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));

        glassesProgramId.setMat4("model", model);
        static_meshes_3D::Cylinder glass(0.4, 50, 0.05, true, true, true);
        //draw first glass
        glass.render();

        //model matrix for world transformation of second glass
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(1.9f, 0.22f, -1.05f));
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::rotate(model, glm::radians(35.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));

        glassesProgramId.setMat4("model", model);
        //draw second glass
        glass.render();

        //=============================================================
        //logic for glass frames
        // set lighting Uniforms for pencil base
        setShaderUniforms(glassFramesProgramId, pointLightPositions, projection);

        //bind diffuse map 
        glActiveTexture(GL_TEXTURE14);
        glBindTexture(GL_TEXTURE_2D, blackDiffuseMap);
        //bind specular map (reuse pencil tip textures)
        glActiveTexture(GL_TEXTURE15);
        glBindTexture(GL_TEXTURE_2D, graySpecularMap);

        //select the glass frame vao to render 
        glBindVertexArray(glassFramesMesh.vaos[0]);

        //model matrix for world transformation for first frame (left side)
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(0.7f, 0.25f, -1.9f));
        model = glm::rotate(model, glm::radians(-45.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::rotate(model, glm::radians(-10.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::scale(model, glm::vec3(0.05f, 0.15f, 2.0f));

        glassFramesProgramId.setMat4("model", model);

        //draw the first frame
        glDrawArrays(GL_TRIANGLES, 0, glassFramesMesh.nIndices);

        //create model matrix for next frame to render (right side)
        //model matrix for world transformation
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(2.2f, 0.25f, -0.85f));
        model = glm::rotate(model, glm::radians(-30.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::rotate(model, glm::radians(-10.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::scale(model, glm::vec3(0.05f, 0.15f, 2.0f));

        glassFramesProgramId.setMat4("model", model);
        //draw the second frame (right side)
        glDrawArrays(GL_TRIANGLES, 0, glassFramesMesh.nIndices);

        //create model matrix for next frame to render (nose bridge)
        //model matrix for world transformation
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(1.43f, 0.2f, -1.37f));
        model = glm::rotate(model, glm::radians(-35.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::scale(model, glm::vec3(0.35f, 0.15f, 0.03f));

        glassFramesProgramId.setMat4("model", model);
        //draw the last frame
        glDrawArrays(GL_TRIANGLES, 0, glassFramesMesh.nIndices);
        //=====================================================
        
        // sphere logic for golf club object
        //set lighting Uniforms for golf club object
        setShaderUniforms(sphereProgramId, pointLightPositions, projection);
        
        //bind diffuse map
        glActiveTexture(GL_TEXTURE14);
        //glBindTexture(GL_TEXTURE_2D, blackDiffuseMap);
        //bind specular map
        glActiveTexture(GL_TEXTURE15);
        //glBindTexture(GL_TEXTURE_2D, graySpecularMap);

        //model matrix for world transformation
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(-0.25f, 0.2f, -2.25f));
        model = glm::rotate(model, glm::radians(-90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::rotate(model, glm::radians(45.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::scale(model, glm::vec3(1.3f, 2.0f, 1.3f));

        sphereProgramId.setMat4("model", model);
        //sphere(radius, numslices>3, numstacks>2)  slices go horizontal|stacks go vertical
        static_meshes_3D::Sphere ball(0.5, 4, 8, true, true, true);
        ball.renderHalf();

        //========================================================
         //Logic for golf face
         // set lighting Uniforms for golf face
        setShaderUniforms(golfFaceProgramId, pointLightPositions, projection);

        //bind diffuse map
        glActiveTexture(GL_TEXTURE16);
        glBindTexture(GL_TEXTURE_2D, golfFaceDiffuseMap);
        //bind specular map
        glActiveTexture(GL_TEXTURE17);
        glBindTexture(GL_TEXTURE_2D, golfFaceSpecularMap);

        //select the watch face vao to render 
        glBindVertexArray(golfFaceMesh.vaos[0]);
        //model matrix for world transformation
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(0.225f, 0.2f, -2.25f));
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::scale(model, glm::vec3(0.85f, 0.1f, 0.95f));

        golfFaceProgramId.setMat4("model", model);

        //draw the watch face
        glDrawArrays(GL_TRIANGLES, 0, golfFaceMesh.nIndices);

        //====================================================

        // golf shaft insert logic 
        // set lighting Uniforms for golf shaft insert
        setShaderUniforms(golfShaftProgramId, pointLightPositions, projection);

        //bind diffuse map
        glActiveTexture(GL_TEXTURE18);
        glBindTexture(GL_TEXTURE_2D, silverDiffuseMap);
        //bind specular map
        glActiveTexture(GL_TEXTURE19);
        glBindTexture(GL_TEXTURE_2D, silverSpecularMap);

        //model matrix for world transformation
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(0.15f, 0.7f, -2.3f));
        model = glm::rotate(model, glm::radians(-20.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        //model = glm::rotate(model, glm::radians(-35.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        model = glm::scale(model, glm::vec3(1.0f, 0.4f, 1.0f));

        golfShaftProgramId.setMat4("model", model);
        static_meshes_3D::Cylinder shaft(0.08, 120, 0.45, true, true, true);
        shaft.render();

        //=============================================================
        //logic for sticky note
        stickyNoteProgramId.use();
        setShaderUniforms(stickyNoteProgramId, pointLightPositions, projection);

        //bind diffuse map
        glActiveTexture(GL_TEXTURE20);
        glBindTexture(GL_TEXTURE_2D, yellowDiffuseMap);
        //bind specular map
        glActiveTexture(GL_TEXTURE21);
        glBindTexture(GL_TEXTURE_2D, yellowSpecularMap);

        //select the strap vao to render 
        glBindVertexArray(stickyNoteMesh.vaos[0]);
        //model matrix for world transformation
        model = glm::mat4(1.0f);
        scale = glm::mat4(1.0f);
        rotation = glm::mat4(1.0f);
        trans = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(-0.3f, 0.65f, -2.5f));
        model = glm::rotate(model, glm::radians(-10.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::scale(model, glm::vec3(0.6f, 0.08f, 0.8f));

        stickyNoteProgramId.setMat4("model", model);

        //draw the strap
        glDrawArrays(GL_TRIANGLES, 0, stickyNoteMesh.nIndices);

        //======================================================
        //point light logic
        //draw the lamp object(s)
        lightCubeProgramId.use();
        lightCubeProgramId.setMat4("projection", projection);
        lightCubeProgramId.setMat4("view", view);

        //draw as many light bulbs as we have point lights
        //glBindVertexArray(lightCubeMesh.vaos[0]);
        for (unsigned int i = 0; i < 4; i++)
        {
            model = glm::mat4(1.0f);
            model = glm::translate(model, pointLightPositions[i]);
            model = glm::scale(model, glm::vec3(0.2f)); // Make it a smaller sphere
            lightCubeProgramId.setMat4("model", model);
            //glDrawArrays(GL_TRIANGLES, 0, 36);
            //sphere(radius, numslices>3, numstacks>2)  slices go horizontal|stacks go vertical
            static_meshes_3D::Sphere lball(0.5, 8, 16, true, false, false);
            lball.render();
        }

        glfwSwapBuffers(gWindow);
        glfwPollEvents();
    }


    // Release mesh data
    UDestroyMesh(strap1Mesh);
    UDestroyMesh(strap2Mesh);
    UDestroyMesh(watchFaceMesh);
    UDestroyMesh(deskMesh);
    UDestroyMesh(airpodMesh);
    UDestroyMesh(pencilTipMesh);
    UDestroyMesh(lightCubeMesh);
    UDestroyMesh(glassFramesMesh);
    UDestroyMesh(golfFaceMesh);
    UDestroyMesh(stickyNoteMesh);

     // Release shader program
    UDestroyShaderProgram(strapProgramId.ID);
    UDestroyShaderProgram(watchFaceProgramId.ID); 
    UDestroyShaderProgram(deskProgramId.ID);
    UDestroyShaderProgram(airpodProgramId.ID);
    UDestroyShaderProgram(pencilProgramId.ID);
    UDestroyShaderProgram(pencilTipProgramId.ID);
    UDestroyShaderProgram(lightCubeProgramId.ID);
    UDestroyShaderProgram(glassesProgramId.ID);
    UDestroyShaderProgram(glassFramesProgramId.ID);
    UDestroyShaderProgram(sphereProgramId.ID);
    UDestroyShaderProgram(golfFaceProgramId.ID);
    UDestroyShaderProgram(golfShaftProgramId.ID);
    UDestroyShaderProgram(stickyNoteProgramId.ID);

    //release textures
    UDestroyTexture(strapDiffuseMap);
    UDestroyTexture(strapSpecularMap);
    UDestroyTexture(watchDiffuseMap);
    UDestroyTexture(watchSpecularMap);
    UDestroyTexture(deskDiffuseMap);
    UDestroyTexture(deskSpecularMap);
    UDestroyTexture(airpodDiffuseMap);
    UDestroyTexture(airpodSpecularMap);
    UDestroyTexture(pencilDiffuseMap);
    UDestroyTexture(pencilSpecularMap);
    UDestroyTexture(pencilTipDiffuseMap);
    UDestroyTexture(pencilTipSpecularMap);
    UDestroyTexture(glassesDiffuseMap);
    UDestroyTexture(glassesSpecularMap);
    UDestroyTexture(blackDiffuseMap);
    UDestroyTexture(graySpecularMap);
    UDestroyTexture(yellowDiffuseMap);
    UDestroyTexture(yellowSpecularMap);

    glfwTerminate();
    return 0;
}


// Function defintion for UInitialize that initializes GLFW, GLEW, and creates a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);  //set up cursorpos callback
    glfwSetScrollCallback(*window, UMouseScrollCallback);       //set up scroll callback
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);  //set mousebutton callback

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // glad: load all OpenGL function pointers
// ---------------------------------------
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    /* No longer using GLEW
    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }
    */
    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// Function definition for UProcessInput to process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
//logic for keys to be pressed and their appropriate responses
void UProcessInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    //Utilizing camera class object, assign WASD to forward, left, backwards, and right respectively
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    //Utilizing camera class object, assign Q and E to up and down respectively. 
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
    //use "p" key to switch between ortho and perspective projection
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
        std::cout << "P" << std::endl;
        if (isPerspective) {
            isPerspective = false;
        }
        else {
            isPerspective = true;
        }
    }
}


// Function definition for UResizeWindow for glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// Function UMousePositionCallback called by glfw whenever the mouse moves
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}

//Function UMouseScrollCallback called by glfw whenever the mouse scroll wheel scrolls. 
// utilizes Camera object function ProcessMouseScroll and adjusts the movement speed
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// Function UMouseButtonCallback called by glfw to handle mouse button events
// there are no current events linked to each mouse button except a print to console
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}

//Function to set shader uniforms for lighting and projection and view matrices (less specular materials)
void setShaderUniforms(Shader shader, glm::vec3 lightPositions[], glm::mat4& projMat) {

    //view/projection matrices for shaders 
    //glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);
    glm::mat4 view = gCamera.GetViewMatrix();

    //=============================================================
    //logic for watch straps
    //activate shader for straps to set uniforms/draw the objects
    shader.use();
    shader.setVec3("viewPos", gCamera.Position);
    shader.setFloat("material.shininess", 32.0f);
    //set all the uniforms for the light sources
    //directional light
    shader.setVec3("dirLight.direction", -0.2f, -1.0f, -0.3f);
    shader.setVec3("dirLight.ambient", 0.05f, 0.05f, 0.05f);
    shader.setVec3("dirLight.diffuse", 0.4f, 0.4f, 0.4f);
    shader.setVec3("dirLight.specular", 0.5f, 0.5f, 0.5f);
    //point light 1
    shader.setVec3("pointLights[0].position", lightPositions[0]);
    shader.setVec3("pointLights[0].ambient", 0.1f, 0.1f, 0.1f);
    shader.setVec3("pointLights[0].diffuse", pointLight1Color * pointLight1Intensity);
    shader.setVec3("pointLights[0].specular", 1.0f, 1.0f, 1.0f);
    shader.setFloat("pointLights[0].constant", 1.0f);
    shader.setFloat("pointLights[0].linear", 0.09);
    shader.setFloat("pointLights[0].quadratic", 0.032);
    //point light 2
    shader.setVec3("pointLights[1].position", lightPositions[1]);
    shader.setVec3("pointLights[1].ambient", 0.1f, 0.1f, 0.1f);
    shader.setVec3("pointLights[1].diffuse", pointLight2Color * pointLight2Intensity);
    shader.setVec3("pointLights[1].specular", 1.0f, 1.0f, 1.0f);
    shader.setFloat("pointLights[1].constant", 1.0f);
    shader.setFloat("pointLights[1].linear", 0.09);
    shader.setFloat("pointLights[1].quadratic", 0.032);
    //point light 3
    shader.setVec3("pointLights[2].position", lightPositions[2]);
    shader.setVec3("pointLights[2].ambient", 0.1f, 0.1f, 0.1f);
    shader.setVec3("pointLights[2].diffuse", pointLight1Color * pointLight1Intensity);
    shader.setVec3("pointLights[2].specular", 1.0f, 1.0f, 1.0f);
    shader.setFloat("pointLights[2].constant", 1.0f);
    shader.setFloat("pointLights[2].linear", 0.09);
    shader.setFloat("pointLights[2].quadratic", 0.032);
    //point light 4
    shader.setVec3("pointLights[3].position", lightPositions[3]);
    shader.setVec3("pointLights[3].ambient", 0.1f, 0.1f, 0.1f);
    shader.setVec3("pointLights[3].diffuse", pointLight2Color * pointLight2Intensity);
    shader.setVec3("pointLights[3].specular", 1.0f, 1.0f, 1.0f);
    shader.setFloat("pointLights[3].constant", 1.0f);
    shader.setFloat("pointLights[3].linear", 0.09);
    shader.setFloat("pointLights[3].quadratic", 0.032);

    // spotLight
    shader.setVec3("spotLight.position", gCamera.Position);
    shader.setVec3("spotLight.direction", gCamera.Front);
    shader.setVec3("spotLight.ambient", 0.0f, 0.0f, 0.0f);
    shader.setVec3("spotLight.diffuse", 1.0f, 1.0f, 1.0f);
    shader.setVec3("spotLight.specular", 1.0f, 1.0f, 1.0f);
    shader.setFloat("spotLight.constant", 1.0f);
    shader.setFloat("spotLight.linear", 0.09);
    shader.setFloat("spotLight.quadratic", 0.032);
    shader.setFloat("spotLight.cutOff", glm::cos(glm::radians(12.5f)));
    shader.setFloat("spotLight.outerCutOff", glm::cos(glm::radians(15.0f)));

    //set view/projection transformation matrices
    shader.setMat4("projection", projMat);
    shader.setMat4("view", view);
}

//Function to set shader uniforms for lighting and projection and view matrices (more specular materials)
void setFaceShaderUniforms(Shader shader, glm::vec3 lightPositions[], glm::mat4& projMat) {
    //view/projection matrices for shaders 
    //glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);
    glm::mat4 view = gCamera.GetViewMatrix();
    
    //activate shader for straps to set uniforms/draw the objects
    shader.use();
    shader.setVec3("viewPos", gCamera.Position);
    shader.setFloat("material.shininess", 32.0f);
    //set all the uniforms for the light sources
    //directional light
    shader.setVec3("dirLight.direction", 0.0f, -2.0f, 0.0f);
    shader.setVec3("dirLight.ambient", 1.0f, 1.0f, 1.0f);
    shader.setVec3("dirLight.diffuse", 1.0f, 1.0f, 1.0f);
    shader.setVec3("dirLight.specular", 0.5f, 0.5f, 0.5f);
    //point light 1
    shader.setVec3("pointLights[0].position", lightPositions[0]);
    shader.setVec3("pointLights[0].ambient", 1.0f, 1.0f, 1.0f);
    shader.setVec3("pointLights[0].diffuse", pointLight1Color * pointLight1Intensity);
    shader.setVec3("pointLights[0].specular", 1.0f, 1.0f, 1.0f);
    shader.setFloat("pointLights[0].constant", 1.0f);
    shader.setFloat("pointLights[0].linear", 0.09);
    shader.setFloat("pointLights[0].quadratic", 0.032);
    //point light 2
    shader.setVec3("pointLights[1].position", lightPositions[1]);
    shader.setVec3("pointLights[1].ambient", 1.0f, 1.0f, 1.0f);
    shader.setVec3("pointLights[1].diffuse", pointLight2Color * pointLight2Intensity);
    shader.setVec3("pointLights[1].specular", 1.0f, 1.0f, 1.0f);
    shader.setFloat("pointLights[1].constant", 1.0f);
    shader.setFloat("pointLights[1].linear", 0.09);
    shader.setFloat("pointLights[1].quadratic", 0.032);
    //point light 3
    shader.setVec3("pointLights[2].position", lightPositions[2]);
    shader.setVec3("pointLights[2].ambient", 1.0f, 1.0f, 1.0f);
    shader.setVec3("pointLights[2].diffuse", pointLight1Color * pointLight1Intensity);
    shader.setVec3("pointLights[2].specular", 1.0f, 1.0f, 1.0f);
    shader.setFloat("pointLights[2].constant", 1.0f);
    shader.setFloat("pointLights[2].linear", 0.09);
    shader.setFloat("pointLights[2].quadratic", 0.032);
    //point light 4              
    shader.setVec3("pointLights[3].position", lightPositions[3]);
    shader.setVec3("pointLights[3].ambient", 1.0f, 1.0f, 1.0f);
    shader.setVec3("pointLights[3].diffuse", pointLight2Color * pointLight2Intensity);
    shader.setVec3("pointLights[3].specular", 1.0f, 1.0f, 1.0f);
    shader.setFloat("pointLights[3].constant", 1.0f);
    shader.setFloat("pointLights[3].linear", 0.09);
    shader.setFloat("pointLights[3].quadratic", 0.032);

    // spotLight
    shader.setVec3("spotLight.position", gCamera.Position);
    shader.setVec3("spotLight.direction", gCamera.Front);
    shader.setVec3("spotLight.ambient", 1.0f, 1.0f, 1.0f);
    shader.setVec3("spotLight.diffuse", 1.0f, 1.0f, 1.0f);
    shader.setVec3("spotLight.specular", 1.0f, 1.0f, 1.0f);
    shader.setFloat("spotLight.constant", 1.0f);
    shader.setFloat("spotLight.linear", 0.09);
    shader.setFloat("spotLight.quadratic", 0.032);
    shader.setFloat("spotLight.cutOff", glm::cos(glm::radians(12.5f)));
    shader.setFloat("spotLight.outerCutOff", glm::cos(glm::radians(15.0f)));

    //set view/projection transformation matrices
    shader.setMat4("projection", projMat);
    shader.setMat4("view", view);
}

//function definition to create a mesh that stores vertex data and attributes for light cubes
void createLightCubeMesh(GLMesh& mesh) {
    //create and draw the lamp objects(s)
    //set up vertex data and buffer(s) and configure vertex attributes
    float cubeVertices[] = {
        // positions          // normals           // texture coords
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  0.0f,
         0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  0.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  1.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  1.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  1.0f,
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  0.0f,

        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,
         0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  0.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  1.0f,
        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,

        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
        -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
        -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,

         0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
         0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
         0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
         0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
         0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
         0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,

        -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,
         0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  1.0f,
         0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
         0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
        -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  0.0f,
        -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,

        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  1.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  0.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f
    };
    //assign the number of floats for each vertex attribute
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, mesh.vaos);
    glBindVertexArray(mesh.vaos[0]);

    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVertices), cubeVertices, GL_STATIC_DRAW);

    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    //update the lamp's position attribute's stride to reflect the updated buffer data
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
}
//function definition to create a mesh that stores vertex data and attributes for watch straps
void createStrapMesh(GLMesh& mesh) {
    //position and color vertex data for the watch's strap1
    GLfloat vertsStrap1[] = {
        //triangle 1    (front)
        // Vertex Positions     //Normals                //textures coordinates
        0.5f,  0.5f, 0.0f,      0.0f,  0.0f,  1.0f,      1.0f, 1.0f,   // v0 Top Right Vertex 0
        0.5f, -0.5f, 0.0f,      0.0f,  0.0f,  1.0f,     1.0f, 0.0f,   // v1 Bottom Right Vertex 1
        -0.5f,  0.5f, 0.0f,     0.0f,  0.0f,  1.0f,     0.0f, 1.0f,   // v3 Top Left Vertex 3
        //triangle 2    (front)
        0.5f, -0.5f, 0.0f,      0.0f,  0.0f,  1.0f,      1.0f, 0.0f,   // v1 Bottom Right Vertex 1
        -0.5f, -0.5f, 0.0f,     0.0f,  0.0f,  1.0f,      0.0f, 0.0f,   // v2 Bottom Left Vertex 2
        -0.5f,  0.5f, 0.0f,     0.0f,  0.0f,  1.0f,     0.0f, 1.0f,   // v3 Top Left Vertex 3
        //triangle 3     (right)
        0.5f,  0.5f, 0.0f,      1.0f,  0.0f,  0.0f,     1.0f, 1.0f,   // v0 Top Right Vertex 0
        0.5f, -0.5f, 0.0f,      1.0f,  0.0f,  0.0f,     1.0f, 0.0f,   // v1 Bottom Right Vertex 1
        0.5f, -0.5f, -1.0f,     1.0f,  0.0f,  0.0f,     0.0f, 0.0f,    // v4 bottom right back
        //triangle 4    (right)
        0.5f,  0.5f, 0.0f,      1.0f,  0.0f,  0.0f,     1.0f, 1.0f,   // v0 Top Right Vertex 0
        0.5f, -0.5f, -1.0f,     1.0f,  0.0f,  0.0f,    0.0f, 0.0f,    // v4 bottom right back
        0.5f,  0.5f, -1.0f,     1.0f,  0.0f,  0.0f,    0.0f, 1.0f,  //  v5 top right back
        //tirangle 5    (back)
        0.5f, -0.5f, -1.0f,     0.0f,  0.0f,  -1.0f,    0.0f, 0.0f,    // v4 bottom right back
         0.5f,  0.5f, -1.0f,    0.0f,  0.0f,  -1.0f,    0.0f, 1.0f,  //  v5 top right back
        -0.5f,  0.5f, -1.0f,    0.0f,  0.0f,  -1.0f,    1.0f, 1.0f,   //  v6 top left back
        //triangle 6    (back)
        0.5f, -0.5f, -1.0f,     0.0f,  0.0f,  -1.0f,    0.0f, 0.0f,    // v4 bottom right back
        -0.5f,  0.5f, -1.0f,    0.0f,  0.0f,  -1.0f,    1.0f, 1.0f,   //  v6 top left back
        -0.5f, -0.5f, -1.0f,    0.0f,  0.0f,  -1.0f,     1.0f, 0.0f,   //  v7 bottom left back
        //triangle 7        (left)
        -0.5f, -0.5f, 0.0f,    -1.0f,  0.0f,  0.0f,    0.0f, 0.0f,   // v2 Bottom Left Vertex 2
        -0.5f,  0.5f, 0.0f,    -1.0f,  0.0f,  0.0f,    0.0f, 1.0f,   // v3 Top Left Vertex 3
        -0.5f, -0.5f, -1.0f,   -1.0f,  0.0f,  0.0f,     1.0f, 0.0f,   //  v7 bottom left back
        //triangle 8    (left)
        -0.5f,  0.5f, 0.0f,    -1.0f,  0.0f,  0.0f,    0.0f, 1.0f,   // v3 Top Left Vertex 3
        -0.5f,  0.5f, -1.0f,   -1.0f,  0.0f,  0.0f,    1.0f, 1.0f,   //  v6 top left back
        -0.5f, -0.5f, -1.0f,   -1.0f,  0.0f,  0.0f,     1.0f, 0.0f,   //  v7 bottom left back
        //triangle 9 (bottom)
        0.5f, -0.5f, 0.0f,     0.0f, -1.0f, 0.0f,     0.0f, 0.0f,   // v1 Bottom Right Vertex 1
        -0.5f, -0.5f, 0.0f,    0.0f, -1.0f, 0.0f,    0.0f, 1.0f,   // v2 Bottom Left Vertex 2
         0.5f, -0.5f, -1.0f,   0.0f, -1.0f, 0.0f,    1.0f, 0.0f,    // v4 bottom right back
         //triangle 10 (bottom)
         -0.5f, -0.5f, 0.0f,   0.0f, -1.0f, 0.0f,    0.0f, 1.0f,   // v2 Bottom Left Vertex 2
         0.5f, -0.5f, -1.0f,   0.0f, -1.0f, 0.0f,    1.0f, 0.0f,    // v4 bottom right back
         -0.5f, -0.5f, -1.0f,  0.0f, -1.0f, 0.0f,     1.0f, 1.0f,   //  v7 bottom left back
         //triangle 11  (top)
         0.5f,  0.5f, 0.0f,    0.0f, 1.0f, 0.0f,     0.0f, 0.0f,   // v0 Top Right Vertex 0    
         -0.5f,  0.5f, 0.0f,   0.0f, 1.0f, 0.0f,    0.0f, 1.0f,   // v3 Top Left Vertex 3    
         0.5f,  0.5f, -1.0f,   0.0f, 1.0f, 0.0f,    1.0f, 0.0f,  //  v5 top right back         
         //triangle 12 (top)
         -0.5f,  0.5f, 0.0f,   0.0f, 1.0f, 0.0f,    0.0f, 1.0f,   // v3 Top Left Vertex 3
         0.5f,  0.5f, -1.0f,   0.0f, 1.0f, 0.0f,    1.0f, 0.0f,  //  v5 top right back
        -0.5f,  0.5f, -1.0f,   0.0f, 1.0f, 0.0f,    1.0f, 1.0f,   //  v6 top left back

    };

    //declare and assign number of floats for each vertex and color and texture coordinates
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nIndices = sizeof(vertsStrap1) / sizeof(vertsStrap1[0]);

    //generate a VAO and bind the VBO for the watch strap1
    glGenVertexArrays(1, mesh.vaos);
    glBindVertexArray(mesh.vaos[0]);

    // Create 1 buffer for the vertex data
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertsStrap1), vertsStrap1, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    //pointer for the position data
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    //pointer for the normals data
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    //pointer for the texture data
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

//function definition to create a mesh that stores vertex data and attributes for watch face
void createFaceMesh(GLMesh& mesh) {
    //position and color vertex data for the watch's face
    GLfloat vertsFace[] = {
        //triangle 1 (front)
        // Vertex Positions    //Normals                //textures coordinates
        0.5f,  0.5f, 0.0f,    0.0f,  0.0f,  1.0f,     0.0f, 0.5f,   // v0 Top Right Vertex 0
        0.5f, -0.5f, 0.0f,    0.0f,  0.0f,  1.0f,     0.0f, 0.5f,  // v1 Bottom Right Vertex 1
        -0.5f,  0.5f, 0.0f,   0.0f,  0.0f,  1.0f,    0.0f, 0.5f,   // v3 Top Left Vertex 3
        //triangle 2 (front)
        0.5f, -0.5f, 0.0f,   0.0f,  0.0f,  1.0f,     0.0f, 0.5f,   // v1 Bottom Right Vertex 1
        -0.5f, -0.5f, 0.0f,   0.0f,  0.0f,  1.0f,    0.0f, 0.5f,   // v2 Bottom Left Vertex 2
        -0.5f,  0.5f, 0.0f,   0.0f,  0.0f,  1.0f,    0.0f, 0.5f,   // v3 Top Left Vertex 3
        //triangle 3 (right)
        0.5f,  0.5f, 0.0f,   1.0f,  0.0f,  0.0f,      0.0f, 0.5f,    // v0 Top Right Vertex 0
        0.5f, -0.5f, 0.0f,   1.0f,  0.0f,  0.0f,     0.0f, 0.5f,   // v1 Bottom Right Vertex 1
        0.5f, -0.5f, -1.0f,  1.0f,  0.0f,  0.0f,     0.0f, 0.5f,     // v4 bottom right back
        //triangle 4  (right)
        0.5f,  0.5f, 0.0f,   1.0f,  0.0f,  0.0f,     0.0f, 0.5f,  // v0 Top Right Vertex 0
        0.5f, -0.5f, -1.0f,  1.0f,  0.0f,  0.0f,     0.0f, 0.5f,    // v4 bottom right back
        0.5f,  0.5f, -1.0f,  1.0f,  0.0f,  0.0f,     0.0f, 0.5f,   //  v5 top right back
        //tirangle 5 (back)
        0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  -1.0f,     0.0f, 0.5f,     // v4 bottom right back
         0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  -1.0f,     0.0f, 0.5f,   //  v5 top right back
        -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  -1.0f,     0.0f, 0.5f,    //  v6 top left back
        //triangle 6    (back)
        0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  -1.0f,     0.0f, 0.5f,    // v4 bottom right back
        -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  -1.0f,     0.0f, 0.5f,   //  v6 top left back
        -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  -1.0f,      0.0f, 0.5f,   //  v7 bottom left back
        //triangle 7    (left)
        -0.5f, -0.5f, 0.0f,   -1.0f,  0.0f,  0.0f,    0.0f, 0.5f,    // v2 Bottom Left Vertex 2
        -0.5f,  0.5f, 0.0f,   -1.0f,  0.0f,  0.0f,    0.0f, 0.5f,   // v3 Top Left Vertex 3
        -0.5f, -0.5f, -1.0f,  -1.0f,  0.0f,  0.0f,    0.0f, 0.5f,    //  v7 bottom left back
        //triangle 8    (left)
        -0.5f,  0.5f, 0.0f,   -1.0f,  0.0f,  0.0f,    0.0f, 0.5f,    // v3 Top Left Vertex 3
        -0.5f,  0.5f, -1.0f,  -1.0f,  0.0f,  0.0f,   0.0f, 0.5f,   //  v6 top left back
        -0.5f, -0.5f, -1.0f,  -1.0f,  0.0f,  0.0f,     0.0f, 0.5f,   //  v7 bottom left back
        //triangle 9 (bottom)
        0.5f, -0.5f, 0.0f,   0.0f, -1.0f, 0.0f,    0.0f, 0.0f,    // v1 Bottom Right Vertex 1
        -0.5f, -0.5f, 0.0f,   0.0f, -1.0f, 0.0f,    0.0f, 0.0f,    // v2 Bottom Left Vertex 2
         0.5f, -0.5f, -1.0f,  0.0f, -1.0f, 0.0f,    0.0f, 0.0f,     // v4 bottom right back
         //triangle 10 (bottom)
         -0.5f, -0.5f, 0.0f,   0.0f, -1.0f, 0.0f,   0.0f, 0.0f,   // v2 Bottom Left Vertex 2
         0.5f, -0.5f, -1.0f, 0.0f, -1.0f, 0.0f,   0.0f, 0.0f,     // v4 bottom right back
         -0.5f, -0.5f, -1.0f,  0.0f, -1.0f, 0.0f,   0.0f, 0.0f,   //  v7 bottom left back
         //triangle 11  (top)
         0.5f,  0.5f, 0.0f,   0.0f, 1.0f, 0.0f,     0.0f, 0.0f,   // v0 Top Right Vertex 0
         -0.5f,  0.5f, 0.0f,   0.0f, 1.0f, 0.0f,     0.0f, 1.0f,   // v3 Top Left Vertex 3
         0.5f,  0.5f, -1.0f,  0.0f, 1.0f, 0.0f,     1.0f, 0.0f,  //  v5 top right back
         //triangle 12 (top)
         -0.5f,  0.5f, 0.0f,   0.0f, 1.0f, 0.0f,     0.0f, 1.0f,   // v3 Top Left Vertex 3
         0.5f,  0.5f, -1.0f, 0.0f, 1.0f, 0.0f,     1.0f, 0.0f,  //  v5 top right back
        -0.5f,  0.5f, -1.0f,  0.0f, 1.0f, 0.0f,     1.0f, 1.0f,   //  v6 top left back

    };
    //declare and assign number of floats for each vertex and color and texture coordinates
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nIndices = sizeof(vertsFace) / sizeof(vertsFace[0]);

    //generate a VAO and bind the VBO for the watch strap1
    glGenVertexArrays(1, mesh.vaos);
    glBindVertexArray(mesh.vaos[0]);

    // Create 1 buffer for the vertex data
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertsFace), vertsFace, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    //pointer for the position data
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    //pointer for the normals data
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    //pointer for the texture data
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

//function definition to create a mesh that stores vertex data and attributes for watch desk
void createDeskMesh(GLMesh& mesh) {
    //vertex attributes for the desk item
    GLfloat vertsDesk[] = {
        //vertex positions          normals                   texture
         //triangle 1 front face    positive Z normal         texture coords
        0.5f,  0.5f, 0.0f,          0.0f,  0.0f,  1.0f,         0.0f, 1.0f,   // v0 Top Right Vertex 0
        0.5f, -0.5f, 0.0f,          0.0f,  0.0f,  1.0f,         1.0f, 0.0f,   // v1 Bottom Right Vertex 1
        -0.5f,  0.5f, 0.0f,         0.0f,  0.0f,  1.0f,         0.0f, 1.0f,   // v3 Top Left Vertex 3
        //triangle 2
        0.5f, -0.5f, 0.0f,          0.0f,  0.0f,  1.0f,     1.0f, 0.0f,   // v1 Bottom Right Vertex 1
        -0.5f, -0.5f, 0.0f,         0.0f,  0.0f,  1.0f,    0.0f, 0.0f,   // v2 Bottom Left Vertex 2
        -0.5f,  0.5f, 0.0f,         0.0f,  0.0f,  1.0f,    0.0f, 1.0f,   // v3 Top Left Vertex 3
        //triangle 3
        0.5f,  0.5f, 0.0f,          1.0f,  0.0f,  0.0f,     1.0f, 1.0f,   // v0 Top Right Vertex 0
        0.5f, -0.5f, 0.0f,          1.0f,  0.0f,  0.0f,     1.0f, 0.0f,   // v1 Bottom Right Vertex 1
        0.5f, -0.5f, -1.0f,         1.0f,  0.0f,  0.0f,    0.0f, 0.0f,    // v4 bottom right back
        //triangle 4
        0.5f,  0.5f, 0.0f,          1.0f,  0.0f,  0.0f,     1.0f, 1.0f,   // v0 Top Right Vertex 0
        0.5f, -0.5f, -1.0f,         1.0f,  0.0f,  0.0f,    0.0f, 0.0f,    // v4 bottom right back
        0.5f,  0.5f, -1.0f,         1.0f,  0.0f,  0.0f,    0.0f, 1.0f,  //  v5 top right back
        //tirangle 5
        0.5f, -0.5f, -1.0f,         0.0f,  0.0f,  -1.0f,     0.0f, 0.0f,    // v4 bottom right back
         0.5f,  0.5f, -1.0f,        0.0f,  0.0f,  -1.0f,     0.0f, 1.0f,  //  v5 top right back
        -0.5f,  0.5f, -1.0f,        0.0f,  0.0f,  -1.0f,     1.0f, 1.0f,   //  v6 top left back
        //triangle 6
        0.5f, -0.5f, -1.0f,         0.0f,  0.0f,  -1.0f,     0.0f, 0.0f,    // v4 bottom right back
        -0.5f,  0.5f, -1.0f,        0.0f,  0.0f,  -1.0f,     1.0f, 1.0f,   //  v6 top left back
        -0.5f, -0.5f, -1.0f,        0.0f,  0.0f,  -1.0f,      1.0f, 0.0f,   //  v7 bottom left back
        //triangle 7
        -0.5f, -0.5f, 0.0f,         -1.0f,  0.0f,  0.0f,     0.0f, 0.0f,   // v2 Bottom Left Vertex 2
        -0.5f,  0.5f, 0.0f,         -1.0f,  0.0f,  0.0f,     0.0f, 1.0f,   // v3 Top Left Vertex 3
        -0.5f, -0.5f, -1.0f,        -1.0f,  0.0f,  0.0f,      1.0f, 0.0f,   //  v7 bottom left back
        //triangle 8
        -0.5f,  0.5f, 0.0f,         -1.0f,  0.0f,  0.0f,     0.0f, 1.0f,   // v3 Top Left Vertex 3
        -0.5f,  0.5f, -1.0f,        -1.0f,  0.0f,  0.0f,     1.0f, 1.0f,   //  v6 top left back
        -0.5f, -0.5f, -1.0f,        -1.0f,  0.0f,  0.0f,      1.0f, 0.0f,   //  v7 bottom left back
        //triangle 9 (bottom)
        0.5f, -0.5f, 0.0f,           0.0f, -1.0f, 0.0f,    1.0f, 0.0f,   // v1 Bottom Right Vertex 1
        -0.5f, -0.5f, 0.0f,         0.0f, -1.0f, 0.0f,    0.0f, 0.0f,   // v2 Bottom Left Vertex 2
         0.5f, -0.5f, -1.0f,         0.0f, -1.0f, 0.0f,    1.0f, 1.0f,    // v4 bottom right back
         //triangle 10 (bottom)
         -0.5f, -0.5f, 0.0f,        0.0f, -1.0f, 0.0f,    0.0f, 0.0f,   // v2 Bottom Left Vertex 2
         0.5f, -0.5f, -1.0f,        0.0f, -1.0f, 0.0f,    1.0f, 1.0f,    // v4 bottom right back
         -0.5f, -0.5f, -1.0f,       0.0f, -1.0f, 0.0f,     0.0f, 1.0f,   //  v7 bottom left back
         //triangle 11  (top)
         0.5f,  0.5f, 0.0f,         0.0f, 1.0f, 0.0f,     1.0f, 0.0f,   // v0 Top Right Vertex 0
         -0.5f,  0.5f, 0.0f,        0.0f, 1.0f, 0.0f,    0.0f, 0.0f,   // v3 Top Left Vertex 3
         0.5f,  0.5f, -1.0f,        0.0f, 1.0f, 0.0f,    1.0f, 1.0f,  //  v5 top right back
         //triangle 12 (top)
         -0.5f,  0.5f, 0.0f,        0.0f, 1.0f, 0.0f,    0.0f, 0.0f,   // v3 Top Left Vertex 3
         0.5f,  0.5f, -1.0f,        0.0f, 1.0f, 0.0f,    1.0f, 1.0f,  //  v5 top right back
        -0.5f,  0.5f, -1.0f,        0.0f, 1.0f, 0.0f,    0.0f, 1.0f,   //  v6 top left back

    };


    //declare and assign number of floats for each vertex and color and texture coordinates
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nIndices = sizeof(vertsDesk) / sizeof(vertsDesk[0]);

    //generate a VAO and bind the VBO for the watch strap1
    glGenVertexArrays(1, mesh.vaos);
    glBindVertexArray(mesh.vaos[0]);

    // Create 1 buffer for the vertex data
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertsDesk), vertsDesk, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    //pointer for the position data
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    //pointer for the normals data
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    //pointer for the texture data
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}
//Function definition for UCreateMesh that stores vertex data and indices 
void createAirpodMesh(GLMesh& mesh)
{
    //vertex attributes for the airpods
    GLfloat vertsAirpod[] = {
        //triangle 1 (front)
        // Vertex Positions    //Normals                 Textures
        0.5f,  0.5f, 0.0f,   0.0f,  0.0f,  1.0f,    0.25f, 0.25f,   // v0 Top Right Vertex 0
        0.5f, -0.5f, 0.0f,   0.0f,  0.0f,  1.0f,    0.25f, 0.25f,    // v1 Bottom Right Vertex 1
        -0.5f,  0.5f, 0.0f,  0.0f,  0.0f,  1.0f,   0.25f, 0.25f,     // v3 Top Left Vertex 3
        //triangle 2 (front)
        0.5f, -0.5f, 0.0f,   0.0f,  0.0f,  1.0f,    0.25f, 0.25f,    // v1 Bottom Right Vertex 1
        -0.5f, -0.5f, 0.0f,   0.0f,  0.0f,  1.0f,   0.25f, 0.25f,    // v2 Bottom Left Vertex 2
        -0.5f,  0.5f, 0.0f,   0.0f,  0.0f,  1.0f,   0.25f, 0.25f,   // v3 Top Left Vertex 3
        //triangle 3 (right)
        0.5f,  0.5f, 0.0f,   1.0f,  0.0f,  0.0f,    0.25f, 0.25f,     // v0 Top Right Vertex 0
        0.5f, -0.5f, 0.0f,   1.0f,  0.0f,  0.0f,    0.25f, 0.25f,   // v1 Bottom Right Vertex 1
        0.5f, -0.5f, -1.0f,  1.0f,  0.0f,  0.0f,    0.25f, 0.25f,      // v4 bottom right back
        //triangle 4  (right)
        0.5f,  0.5f, 0.0f,   1.0f,  0.0f,  0.0f,    0.25f, 0.25f,  // v0 Top Right Vertex 0
        0.5f, -0.5f, -1.0f,  1.0f,  0.0f,  0.0f,   0.25f, 0.25f,   // v4 bottom right back
        0.5f,  0.5f, -1.0f,  1.0f,  0.0f,  0.0f,     0.25f, 0.25f, //  v5 top right back
        //tirangle 5 (back)
        0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  -1.0f,     0.25f, 0.25f,   // v4 bottom right back
         0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  -1.0f,     0.25f, 0.25f, //  v5 top right back
        -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  -1.0f,    0.25f, 0.25f,    //  v6 top left back
        //triangle 6    (back)
        0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  -1.0f,       0.25f, 0.25f,   // v4 bottom right back
        -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  -1.0f,      0.25f, 0.25f,   //  v6 top left back
        -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  -1.0f,      0.25f, 0.25f,   //  v7 bottom left back
        //triangle 7    (left)
        -0.5f, -0.5f, 0.0f,   -1.0f,  0.0f,  0.0f,     0.25f, 0.25f,    // v2 Bottom Left Vertex 2
        -0.5f,  0.5f, 0.0f,   -1.0f,  0.0f,  0.0f,     0.25f, 0.25f,   // v3 Top Left Vertex 3
        -0.5f, -0.5f, -1.0f,  -1.0f,  0.0f,  0.0f,     0.25f, 0.25f,   //  v7 bottom left back
        //triangle 8    (left)
        -0.5f,  0.5f, 0.0f,   -1.0f,  0.0f,  0.0f,     0.25f, 0.25f,   // v3 Top Left Vertex 3
        -0.5f,  0.5f, -1.0f,  -1.0f,  0.0f,  0.0f,     0.25f, 0.25f, //  v6 top left back
        -0.5f, -0.5f, -1.0f,  -1.0f,  0.0f,  0.0f,     0.25f, 0.25f,   //  v7 bottom left back
        //triangle 9 (bottom)
        0.5f, -0.5f, 0.0f,   0.0f, -1.0f, 0.0f,      0.25f, 0.25f, // v1 Bottom Right Vertex 1
        -0.5f, -0.5f, 0.0f,   0.0f, -1.0f, 0.0f,     0.25f, 0.25f,  // v2 Bottom Left Vertex 2
         0.5f, -0.5f, -1.0f,  0.0f, -1.0f, 0.0f,     0.25f, 0.25f,  // v4 bottom right back
         //triangle 10 (bottom)
         -0.5f, -0.5f, 0.0f,   0.0f, -1.0f, 0.0f,    0.25f, 0.25f,  // v2 Bottom Left Vertex 2
         0.5f, -0.5f, -1.0f,  0.0f, -1.0f, 0.0f,     0.25f, 0.25f,  // v4 bottom right back
         -0.5f, -0.5f, -1.0f,  0.0f, -1.0f, 0.0f,    0.25f, 0.25f,   //  v7 bottom left back                                                           
        //triangle 11  (top)
         0.5f,  0.5f, 0.0f,   0.0f, 1.0f, 0.0f,     1.0f, 0.0f,  // v0 Top Right Vertex 0
         -0.5f,  0.5f, 0.0f,   0.0f, 1.0f, 0.0f,    0.0f, 0.0f, // v3 Top Left Vertex 3
         0.5f,  0.5f, -1.0f,  0.0f, 1.0f, 0.0f,     1.0f, 1.0f,//  v5 top right back
         //triangle 12 (top)
         -0.5f,  0.5f, 0.0f,   0.0f, 1.0f, 0.0f,    0.0f, 0.0f, // v3 Top Left Vertex 3
         0.5f,  0.5f, -1.0f,  0.0f, 1.0f, 0.0f,    1.0f, 1.0f,//  v5 top right back
        -0.5f,  0.5f, -1.0f,  0.0f, 1.0f, 0.0f,     0.0f, 1.0f//  v6 top left back

    };

    //declare and assign number of floats for each vertex and color and texture coordinates
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nIndices = sizeof(vertsAirpod) / sizeof(vertsAirpod[0]);

    //generate a VAO and bind the VBO for the watch strap1
    glGenVertexArrays(1, mesh.vaos);
    glBindVertexArray(mesh.vaos[0]);

    // Create 1 buffer for the vertex data
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertsAirpod), vertsAirpod, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    //pointer for the position data
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    //pointer for the normals data
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    //pointer for the texture data
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);

}

void createPencilTipMesh(GLMesh& mesh) {
    //vertex attributes for the pencil tip
    GLfloat vertsTip[] = {
        //vertex positions          normals                   texture
         //triangle 1 front face    positive Z normal         texture coords
         -2.0f,  0.5f, 0.0f,         0.0f,  0.0f,  1.0f,       0.5f, 1.0f,    //v0 tip
         -2.5f, -0.5f, 0.5f,         0.0f,  0.0f,  1.0f,       0.0f,0.0f,      //v1 bottom left front 
          -1.5f, -0.5f, 0.5f,        0.0f,  0.0f,  1.0f,       1.0f, 0.0f,  //v2 Bottom right front 

          //triangle 2 right face   positive x normal           texture coords
          -2.0f,  0.5f, 0.0f,       1.0f,  0.0f,  0.0f,         0.5f, 1.0f,    //v0 tip
          -1.5f, -0.5f, 0.5f,       1.0f,  0.0f,  0.0f,         0.0f, 0.0f,      //v2 Bottom right front 
          -1.5f, -0.5f, -0.5f,      1.0f,  0.0f,  0.0f,         1.0f, 0.0f,    //v3 Bottom right back 

          //triangle 3 back face    negative Z normal           texture coords
          -2.0f,  0.5f, 0.0f,       0.0f,  0.0f,  -1.0f,        0.5f, 1.0f,    //v0 tip
          -1.5f, -0.5f, -0.5f,      0.0f,  0.0f,  -1.0f,        0.0f, 0.0f,    //v3 Bottom right back 
          -2.5f, -0.5f, -0.5f,      0.0f,  0.0f,  -1.0f,        1.0f, 0.0f,     //v4 bottom back left 

          //triangle 4 left face    negative X normal           texture coords
          -2.0f,  0.5f, 0.0f,       -1.0f,  0.0f,  0.0f,        0.5f, 1.0f,    //v0 tip
          -2.5f, -0.5f, 0.5f,       -1.0f,  0.0f,  0.0f,        0.0f,0.0f,      //v1 bottom left front 
          -2.5f, -0.5f, -0.5f,      -1.0f,  0.0f,  0.0f,        1.0f, 0.0f,     //v4 bottom back left 

          //bottom face triangle 5  negative Y normal           texture coords
          -2.5f, -0.5f, 0.5f,       0.0f, -1.0f, 0.0f,          0.0f,1.0f,      //v1 bottom left front 
          -1.5f, -0.5f, 0.5f,       0.0f, -1.0f, 0.0f,          0.0f, 0.0f,  //v2 Bottom right front 
          -2.5f, -0.5f, -0.5f,      0.0f, -1.0f, 0.0f,          1.0f, 1.0f,     //v4 bottom back left 

           //bottom face triangle 6 negative Y normal           texture coords
          -1.5f, -0.5f, 0.5f,       0.0f, -1.0f, 0.0f,          0.0f, 0.0f,  //v2 Bottom right front 
          -2.5f, -0.5f, -0.5f,      0.0f, -1.0f, 0.0f,          1.0f, 1.0f,     //v4 bottom back left 
          -1.5f, -0.5f, -0.5f,      0.0f, -1.0f, 0.0f,          1.0f, 0.0f    //v3 Bottom right back 
    };

    //declare and assign number of floats for each vertex and color and texture coordinates
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nIndices = sizeof(vertsTip) / sizeof(vertsTip[0]);

    //generate a VAO and bind the VBO for the watch strap1
    glGenVertexArrays(1, mesh.vaos);
    glBindVertexArray(mesh.vaos[0]);

    // Create 1 buffer for the vertex data
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertsTip), vertsTip, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    //pointer for the position data
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    //pointer for the normals data
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    //pointer for the texture data
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

//function to create mesh for vertex data and attributes for the glasses frames 
void createGlassFramesMesh(GLMesh& mesh) {
    //position and color vertex data for the watch's strap1
    GLfloat vertsFrames[] = {
        //triangle 1    (front)
        // Vertex Positions     //Normals                //textures coordinates
        0.5f,  0.5f, 0.0f,      0.0f,  0.0f,  1.0f,      1.0f, 1.0f,   // v0 Top Right Vertex 0
        0.5f, -0.5f, 0.0f,      0.0f,  0.0f,  1.0f,     1.0f, 0.0f,   // v1 Bottom Right Vertex 1
        -0.5f,  0.5f, 0.0f,     0.0f,  0.0f,  1.0f,     0.0f, 1.0f,   // v3 Top Left Vertex 3
        //triangle 2    (front)
        0.5f, -0.5f, 0.0f,      0.0f,  0.0f,  1.0f,      1.0f, 0.0f,   // v1 Bottom Right Vertex 1
        -0.5f, -0.5f, 0.0f,     0.0f,  0.0f,  1.0f,      0.0f, 0.0f,   // v2 Bottom Left Vertex 2
        -0.5f,  0.5f, 0.0f,     0.0f,  0.0f,  1.0f,     0.0f, 1.0f,   // v3 Top Left Vertex 3
        //triangle 3     (right)
        0.5f,  0.5f, 0.0f,      1.0f,  0.0f,  0.0f,     1.0f, 1.0f,   // v0 Top Right Vertex 0
        0.5f, -0.5f, 0.0f,      1.0f,  0.0f,  0.0f,     1.0f, 0.0f,   // v1 Bottom Right Vertex 1
        0.5f, -0.5f, -1.0f,     1.0f,  0.0f,  0.0f,     0.0f, 0.0f,    // v4 bottom right back
        //triangle 4    (right)
        0.5f,  0.5f, 0.0f,      1.0f,  0.0f,  0.0f,     1.0f, 1.0f,   // v0 Top Right Vertex 0
        0.5f, -0.5f, -1.0f,     1.0f,  0.0f,  0.0f,    0.0f, 0.0f,    // v4 bottom right back
        0.5f,  0.5f, -1.0f,     1.0f,  0.0f,  0.0f,    0.0f, 1.0f,  //  v5 top right back
        //tirangle 5    (back)
        0.5f, -0.5f, -1.0f,     0.0f,  0.0f,  -1.0f,    0.0f, 0.0f,    // v4 bottom right back
         0.5f,  0.5f, -1.0f,    0.0f,  0.0f,  -1.0f,    0.0f, 1.0f,  //  v5 top right back
        -0.5f,  0.5f, -1.0f,    0.0f,  0.0f,  -1.0f,    1.0f, 1.0f,   //  v6 top left back
        //triangle 6    (back)
        0.5f, -0.5f, -1.0f,     0.0f,  0.0f,  -1.0f,    0.0f, 0.0f,    // v4 bottom right back
        -0.5f,  0.5f, -1.0f,    0.0f,  0.0f,  -1.0f,    1.0f, 1.0f,   //  v6 top left back
        -0.5f, -0.5f, -1.0f,    0.0f,  0.0f,  -1.0f,     1.0f, 0.0f,   //  v7 bottom left back
        //triangle 7        (left)
        -0.5f, -0.5f, 0.0f,    -1.0f,  0.0f,  0.0f,    0.0f, 0.0f,   // v2 Bottom Left Vertex 2
        -0.5f,  0.5f, 0.0f,    -1.0f,  0.0f,  0.0f,    0.0f, 1.0f,   // v3 Top Left Vertex 3
        -0.5f, -0.5f, -1.0f,   -1.0f,  0.0f,  0.0f,     1.0f, 0.0f,   //  v7 bottom left back
        //triangle 8    (left)
        -0.5f,  0.5f, 0.0f,    -1.0f,  0.0f,  0.0f,    0.0f, 1.0f,   // v3 Top Left Vertex 3
        -0.5f,  0.5f, -1.0f,   -1.0f,  0.0f,  0.0f,    1.0f, 1.0f,   //  v6 top left back
        -0.5f, -0.5f, -1.0f,   -1.0f,  0.0f,  0.0f,     1.0f, 0.0f,   //  v7 bottom left back
        //triangle 9 (bottom)
        0.5f, -0.5f, 0.0f,     0.0f, -1.0f, 0.0f,     0.0f, 0.0f,   // v1 Bottom Right Vertex 1
        -0.5f, -0.5f, 0.0f,    0.0f, -1.0f, 0.0f,    0.0f, 1.0f,   // v2 Bottom Left Vertex 2
         0.5f, -0.5f, -1.0f,   0.0f, -1.0f, 0.0f,    1.0f, 0.0f,    // v4 bottom right back
         //triangle 10 (bottom)
         -0.5f, -0.5f, 0.0f,   0.0f, -1.0f, 0.0f,    0.0f, 1.0f,   // v2 Bottom Left Vertex 2
         0.5f, -0.5f, -1.0f,   0.0f, -1.0f, 0.0f,    1.0f, 0.0f,    // v4 bottom right back
         -0.5f, -0.5f, -1.0f,  0.0f, -1.0f, 0.0f,     1.0f, 1.0f,   //  v7 bottom left back
         //triangle 11  (top)
         0.5f,  0.5f, 0.0f,    0.0f, 1.0f, 0.0f,     0.0f, 0.0f,   // v0 Top Right Vertex 0    
         -0.5f,  0.5f, 0.0f,   0.0f, 1.0f, 0.0f,    0.0f, 1.0f,   // v3 Top Left Vertex 3    
         0.5f,  0.5f, -1.0f,   0.0f, 1.0f, 0.0f,    1.0f, 0.0f,  //  v5 top right back         
         //triangle 12 (top)
         -0.5f,  0.5f, 0.0f,   0.0f, 1.0f, 0.0f,    0.0f, 1.0f,   // v3 Top Left Vertex 3
         0.5f,  0.5f, -1.0f,   0.0f, 1.0f, 0.0f,    1.0f, 0.0f,  //  v5 top right back
        -0.5f,  0.5f, -1.0f,   0.0f, 1.0f, 0.0f,    1.0f, 1.0f,   //  v6 top left back

    };

    //declare and assign number of floats for each vertex and color and texture coordinates
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nIndices = sizeof(vertsFrames) / sizeof(vertsFrames[0]);

    //generate a VAO and bind the VBO for the watch strap1
    glGenVertexArrays(1, mesh.vaos);
    glBindVertexArray(mesh.vaos[0]);

    // Create 1 buffer for the vertex data
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertsFrames), vertsFrames, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    //pointer for the position data
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    //pointer for the normals data
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    //pointer for the texture data
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

//function definition to create a mesh that stores vertex data and attributes for watch desk
void createPlaneMesh(GLMesh& mesh) {
    //vertex attributes for the plane item
    //vertices for a plane
    GLfloat vertsPlane[] = {
        //vertex positions          normals                   texture
       //triangle 1 left        positive Y normal         texture coords
      0.5f,  0.0f, 0.5f,          0.0f,  1.0f,  0.0f,         1.0f, 0.0f,   // v0 Top Right Vertex 0
      -0.5f, 0.0f, 0.5f,          0.0f,  1.0f,  0.0f,         0.0f, 0.0f,   // v1 Bottom Right Vertex 1
      -0.5f,  0.0f, -0.5f,         0.0f, 1.0f,  0.0f,         0.0f, 1.0f,   // v3 Top Left Vertex 3
        //triangle 1 right       positive Y normal         texture coords
      0.5f,  0.0f, 0.5f,          0.0f,  1.0f,  0.0f,         1.0f, 0.0f,   // v0 Top Right Vertex 0
      0.5f, 0.0f, -0.5f,          0.0f,  1.0f,  0.0f,         1.0f, 1.0f,   // v1 Bottom Right Vertex 1
      -0.5f,  0.0f, -0.5f,         0.0f, 1.0f,  0.0f,         0.0f, 1.0f   // v3 Top Left Vertex 3
    };


    //declare and assign number of floats for each vertex and normal and texture coordinates
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nIndices = sizeof(vertsPlane) / sizeof(vertsPlane[0]);

    //generate a VAO and bind the VBO for the watch strap1
    glGenVertexArrays(1, mesh.vaos);
    glBindVertexArray(mesh.vaos[0]);

    // Create 1 buffer for the vertex data
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertsPlane), vertsPlane, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    //pointer for the position data
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    //pointer for the normals data
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    //pointer for the texture data
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

//function UDestroyMesh to delete the mesh VAO and VBOs
void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, mesh.vaos);
    glDeleteBuffers(1, mesh.vbos);
}

/*Function to generate and load the texture*/
bool UCreateTextureRepeat(const char* filename, GLuint& textureId) {
    int width, height, channels;
    stbi_set_flip_vertically_on_load(true); //makes stb_image.h flip loaded image's on the y-axis
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3) {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        }
        else if (channels == 4) {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        }
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}
/*Function to generate and load texture with clamp to border texture wrapping*/
bool UCreateTextureClamp(const char* filename, GLuint& textureId, float borderColor[]) {
    int width, height, channels;
    stbi_set_flip_vertically_on_load(true); //makes stb_image.h flip loaded image's on the y-axis
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, borderColor);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3) {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        }
        else if (channels == 4) {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        }
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}
//function to release the texture data
void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}

//Function UCreateShaderProgram to create a shader program using the vertex shader and fragment shader source code
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}

//function uDestroyShaderProgram to deallocate the shader program
void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}
